SYSADMIN TOOLBOX - OFFLINE ZIP PACKAGE
1. Extraire TOUS les fichiers de cette archive dans le MEME dossier.
2. Sur Windows, double-cliquer sur Lancer-....cmd.
3. La console attend une touche avant de se fermer.
4. Ne pas executer sur une machine de production sans valider le code et son utilisation.
5. Pour Linux-HealthCheck, une distribution WSL installee est requise sous Windows.
6. Pour Network-Doctor, Python 3 est requis.
7. Pour Active Directory, le lanceur est toujours en mode SIMULATION.

ENGLISH:
1. Extract ALL files into the SAME folder.
2. On Windows, double-click Lancer-....cmd.
3. The terminal waits for a keypress before closing.
4. Review scripts and validate in a lab before professional use.
5. Linux-HealthCheck needs an installed WSL Linux distribution on Windows.
6. Network-Doctor requires Python 3.
7. The Active Directory launcher always runs in DRY RUN mode.

Project: https://github.com/YsenGrindel/sysadmin-toolbox